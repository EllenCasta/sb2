JsBarcode("#barcode", "1234", {
    format: "codabar",
    lineColor: "#000",
    width: 4,
    height: 40,
    displayValue: true
  });



  
 /* import { Component } from '@angular/core';
import { BarcodeScannerOptions, BarcodeScanner } from "@ionic-native/barcode-scanner/ngx";
 
@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  datocodificado: any;
  datoscaneado: {};

  constructor(private barcodeScanner: BarcodeScanner) {

  }

  LeerCode() {
    this.barcodeScanner.scan().then(barcodeData => {
        this.datoscaneado = barcodeData;
      })
      .catch(err => {
        console.log("Error", err);
      });
  }
 
  CodificarTexto() {
    this.barcodeScanner.encode(this.barcodeScanner.Encode.TEXT_TYPE, this.datocodificado).then(
        encodedData => {
          this.datocodificado = encodedData;
        },
        err => {
          console.log("Un error ha ocurrido: " + err);
        }
      );
  }
*/

/*app.controller('modalEscanerController', function($scope, $uibModalInstance, codigos){
    var ctrl = this;
    ctrl.init = function(){
        ctrl.barcodeDetector = new BarcodeDetector();

        navigator.mediaDevices.getUserMedia({video: true})
        .then(stream =>{
            const preview = document.getElementById('preview');
            preview.srcObject = stream;
            return preview.play();
        })
        .then(()=>{
            const preview = document.getElementById('preview');
            ctrl.scan(preview);
        });
    };
    ctrl.scan = function(preview){
        const decodedCodes = new Set();
        ctrl.barcodeDetector.detect(preview)
        .then(result => {
            if (!result) {
                setTimeout(()=> ctrl.scan(preview),500);
                return;
            }
            if(!decodedCodes.has(result.rawValue)){
                decodedCodes.add(result.rawValue);
                codigos.push(result.rawValue);
            }
            setTimeout(()=>ctrl.scan(preview,500));
           
        });
    };
    ctrl.init();
});*/

